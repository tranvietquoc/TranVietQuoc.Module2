package casestudy_module2.services;

public interface FacilityService {
    public void display();
    public void displayMainTain();
    public void addNewVilla();
    public void addNewHouse();
    public void addNewRoom();
}
