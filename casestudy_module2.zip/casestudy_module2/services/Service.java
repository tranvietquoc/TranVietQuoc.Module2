package casestudy_module2.services;

public interface Service {
    public void display ();
    public void addNew ();
    public void edit ();
    public void delete ();
}
