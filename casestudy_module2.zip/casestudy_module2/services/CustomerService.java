package casestudy_module2.services;

public interface CustomerService extends Service {

}
