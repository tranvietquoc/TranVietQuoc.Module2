package casestudy_module2.services;

public interface EmployeeService extends Service {
}
